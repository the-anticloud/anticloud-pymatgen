# 34 Founder Profile

**Project:** PYMATGEN
**Upstream:** https://github.com/materialsproject/pymatgen

Content specific to PYMATGEN in category CHEMICAL_MANUFACTURING.
